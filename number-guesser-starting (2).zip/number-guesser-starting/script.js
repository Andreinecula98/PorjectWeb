let humanScore = 0;
let computerScore = 0;
let currentRoundNumber = 1;

function generateTarget(){
	return Math.floor(Math.random()*9);
}

function compareGuesses(human,computer,target){
	if(Math.abs(target - human) <= Math.abs(target - computer))
    return true;
  else return false;
};
  
function updateScore(the_winner) {
  if(the_winner === 'human') humanScore++;
  else computerScore++;
};
  
function advanceRound(){
  currentRoundNumber++;
};